const patientData=[
{
    id:1,
  name:'jackson Rai',
  gender:'Male',
  email:'jacksonrai@gmail.com',
  age:'25',
  phone:'9808701617',
  startDate:'2019-15-06',
  endingDate:'2020-26-08',
  medicalDiagnosis:'Acute Bronchitis'
},{
    id:2,
    name:'jitenRai',
    gender:'Male',
    email:'jacksonrai@gmail.com',
    age:'25',
    phone:'9808701617',
    startDate:'2019-15-06',
    endingDate:'2020-26-08',
    medicalDiagnosis:'Acute Bronchitis'
  },
  {
      id:3,
    name:'krishRai',
    gender:'Male',
    email:'jacksonrai@gmail.com',
    age:'25',
    phone:'9808701617',
    startDate:'2019-15-06',
    endingDate:'2020-26-08',
    medicalDiagnosis:'Acute Bronchitis'
  }
]
export{
    patientData
}