
import { createContext } from "react";
export const GlobalData=createContext([])