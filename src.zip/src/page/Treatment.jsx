const Treatment=()=>{
    return<>I am Treatment</>
    }
    export default Treatment